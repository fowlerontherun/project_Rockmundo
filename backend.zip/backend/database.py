import sqlite3

DB_PATH = "rockmundo.db"

def initialize_database():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # ==== Bands & Members ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS bands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        genre TEXT,
        founder_user_id INTEGER,
        fame INTEGER DEFAULT 0,
        skill REAL DEFAULT 0,
        revenue REAL DEFAULT 0
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS band_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        user_id INTEGER,
        role TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)

    # ==== Fans ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS fans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        band_id INTEGER,
        location TEXT,
        loyalty INTEGER,
        source TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)

    # ==== Gigs & Tours ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS gigs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        city TEXT,
        venue TEXT,
        date TEXT,
        venue_size INTEGER,
        ticket_price INTEGER,
        attendance INTEGER,
        revenue REAL,
        fame_gain INTEGER,
        status TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS tours (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        start_date TEXT,
        vehicle_type TEXT,
        status TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS tour_stops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tour_id INTEGER,
        city TEXT,
        stop_order INTEGER,
        FOREIGN KEY(tour_id) REFERENCES tours(id)
    )
    """)

    # ==== Songs & Albums ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS songs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        title TEXT,
        duration_sec INTEGER,
        genre TEXT,
        play_count INTEGER DEFAULT 0,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS albums (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        title TEXT,
        album_type TEXT,
        shared_with_band_id INTEGER,
        release_date TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS album_songs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        album_id INTEGER,
        song_id INTEGER,
        FOREIGN KEY(album_id) REFERENCES albums(id),
        FOREIGN KEY(song_id) REFERENCES songs(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS royalties (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        song_id INTEGER,
        user_id INTEGER,
        percent INTEGER,
        FOREIGN KEY(song_id) REFERENCES songs(id)
    )
    """)

    # ==== Venues & Shows ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS venues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        city TEXT,
        country TEXT,
        capacity INTEGER,
        rental_cost REAL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS shows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        venue_id INTEGER,
        date TEXT,
        ticket_price REAL,
        FOREIGN KEY(band_id) REFERENCES bands(id),
        FOREIGN KEY(venue_id) REFERENCES venues(id)
    )
    """)

    # ==== Streaming & Earnings ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS streams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        song_id INTEGER,
        timestamp TEXT,
        FOREIGN KEY(song_id) REFERENCES songs(id)
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS earnings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        source_type TEXT,
        source_id INTEGER,
        amount REAL,
        timestamp TEXT
    )
    """)

    # ==== Live Performances ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS live_performances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        city TEXT,
        venue TEXT,
        date TEXT,
        setlist TEXT,
        crowd_size INTEGER,
        fame_earned INTEGER,
        revenue_earned REAL,
        skill_gain REAL,
        merch_sold INTEGER,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)

    # ==== Fan Interactions ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS fan_interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        fan_id INTEGER,
        interaction_type TEXT,
        content TEXT,
        created_at TEXT,
        FOREIGN KEY(band_id) REFERENCES bands(id)
    )
    """)

    # ==== Community Karma ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS community_karma (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        karma_score INTEGER,
        last_updated TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS karma_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        event_type TEXT,
        description TEXT,
        created_at TEXT
    )
    """)

    # ==== Charts ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS chart_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chart_type TEXT,
        week_start TEXT,
        position INTEGER,
        song_id INTEGER,
        band_name TEXT,
        score REAL,
        generated_at TEXT
    )
    """)

    # ==== Labels ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS labels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        founder_user_id INTEGER,
        sign_up_fee REAL,
        created_at TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS label_bands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label_id INTEGER,
        band_id INTEGER,
        contract_terms TEXT,
        signed_at TEXT
    )
    """)

    # ==== Media Assets ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS media_assets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        media_type TEXT,
        file_path TEXT,
        metadata TEXT,
        created_at TEXT
    )
    """)

    # ==== AI Tour Managers ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS ai_tour_managers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        band_id INTEGER,
        unlocked INTEGER,
        optimization_level INTEGER,
        active_since TEXT
    )
    """)

    # ==== Messaging ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        subject TEXT,
        body TEXT,
        sent_at TEXT,
        read INTEGER,
        deleted INTEGER
    )
    """)

    # ==== Scheduled Tasks ====
    cur.execute("""
    CREATE TABLE IF NOT EXISTS scheduled_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT,
        params TEXT,
        run_at TEXT,
        recurring INTEGER,
        interval_days INTEGER,
        last_run TEXT
    )
    """)

    conn.commit()
    conn.close()