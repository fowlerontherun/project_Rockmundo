import os
import glob
import importlib
import asyncio
import sqlite3
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.database import DB_PATH, initialize_database
from backend.services import scheduler_service

app = FastAPI()

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    if not os.path.exists(DB_PATH):
        print("Initializing database...")
        initialize_database()

    # Start scheduler loop
    asyncio.create_task(scheduler_loop())

# Background scheduler loop
async def scheduler_loop():
    while True:
        try:
            result = scheduler_service.run_due_tasks()
            print(f"Scheduler ran: {result}")
        except Exception as e:
            print(f"Scheduler error: {e}")
        await asyncio.sleep(60)  # run every 60 seconds

# Dynamic route loading
def load_routes():
    route_files = glob.glob("backend/routes/*.py")
    for file in route_files:
        if file.endswith("__init__.py"):
            continue
        module_name = file.replace("/", ".").replace(".py", "")
        module = importlib.import_module(module_name)
        for attr in dir(module):
            obj = getattr(module, attr)
            if hasattr(obj, "router"):
                app.include_router(obj.router)
            elif hasattr(obj, "blueprint"):
                app.include_router(obj)

load_routes()

# Health-check endpoint
@app.get("/health")
def health():
    db_exists = os.path.exists(DB_PATH)
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.close()
        db_ok = True
    except:
        db_ok = False
    return {"status": "ok", "db_exists": db_exists, "db_ok": db_ok}